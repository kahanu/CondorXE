/*
===============================================================
            CondorXE Code Generator - ver 2.0.0.2
       Generated using MyGeneration Software - ver 1.3.0.9
       Created By King Wilder - http://www.kingwilder.com
                   12/7/2011 4:09:33 PM
===============================================================
*/
using System;
using System.Configuration;

namespace $safeprojectname$
{
	public class ConfigSettings
	{
		public static string SiteTitle { get { return ConfigurationManager.AppSettings["SiteTitle"]; } }
		public static string MetaKeywords { get { return ConfigurationManager.AppSettings["MetaKeywords"]; } }
		public static string MetaDescription { get { return ConfigurationManager.AppSettings["MetaDescription"]; } }
		public static string FromEmail { get { return ConfigurationManager.AppSettings["FromEmail"]; } }
	}
}
