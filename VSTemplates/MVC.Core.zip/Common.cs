/*
===============================================================
            CondorXE Code Generator - ver 2.0.0.2
       Generated using MyGeneration Software - ver 1.3.0.9
       Created By King Wilder - http://www.kingwilder.com
                   12/7/2011 4:09:33 PM
===============================================================
*/
using System.Web;

namespace $safeprojectname$
{
	public class Common
	{
		public static string GetSiteUrl()
		{
			HttpContext current = HttpContext.Current;
			string str = current.Request.ServerVariables["SERVER_PORT"];
			switch (str)
			{
				case null:
				case "80":
				case "443":
					str = "";
					break;
				
				default:
					str = ":" + str;
					break;
				}
				string str2 = current.Request.ServerVariables["SERVER_PORT_SECURE"];
				switch (str2)
				{
					case null:
					case "0":
						str2 = "http://";
						break;
					
					default:
						str2 = "https://";
						break;
					}
					string applicationPath = current.Request.ApplicationPath;
					if (applicationPath == "/")
					{
						applicationPath = "";
					}
					return (str2 + current.Request.ServerVariables["SERVER_NAME"] + str + applicationPath);
				}
			}
		}
