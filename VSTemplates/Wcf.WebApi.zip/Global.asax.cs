﻿using System;
using System.Linq;
using System.Web;

namespace $safeprojectname$
{
    public class Global : HttpApplication
    {

    }
}